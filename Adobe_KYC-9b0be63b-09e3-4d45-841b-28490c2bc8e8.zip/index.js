'use strict';
console.log("Loading function");
var AWS = require("aws-sdk");
AWS.config.update({region: 'us-east-1'});
const docClient = new AWS.DynamoDB.DocumentClient({apiVersion: '2012-08-10'});
let ts = Date.now();
exports.handler = async (event,context,callback) => {
    console.log(event.currentIntent.slots.email);
    var params= {
    "TableName": "account_users",
    "Item": {
      "email": event.currentIntent.slots.email,
      "status": "sent",
      "applicationid":"adobe"+ts
    }
  };
  await docClient.put(params).promise();
  
  
callback(null,{
  'dialogAction': {
   'type':'Close',
   'fulfillmentState': 'Fulfilled',
   'message':{
       'contentType': 'SSML',
       'content':'<speak>Thank you for the details.' +'<break time="500ms"/>'+'. You will receive the email with Account and KYC forms .Kindly fill and send it .Thank you </speak>'
   }}});



  


};
